import 'package:flutter/material.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import '../../ui/pages/category.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      // ignore: unnecessary_new
      theme: new ThemeData(scaffoldBackgroundColor: const Color.fromARGB(255, 237, 237, 237)),
      debugShowCheckedModeBanner: false,
      home: const LoginDemo(),
    );
  }
}

class LoginDemo extends StatefulWidget {
  const LoginDemo({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _LoginDemoState createState() => _LoginDemoState();
}

class _LoginDemoState extends State<LoginDemo> {
  @override
  Widget build(BuildContext context) {
    var center = Center(
                child: SizedBox(
                    width: 200,
                    height: 150,
                    child: Image.asset('asset/images/logo_default.png')),
              );
    var center2 = center;
    return Scaffold(
      // backgroundColor: Colors.white,
      // appBar: AppBar(
      //   title: Text("Login Page"),
      // ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(top: 60.0),
              child: center2,
            ),
            const SizedBox(height: 20),
            const Text(
              'Loggin On',
              textAlign: TextAlign.left,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
            ),
            const SizedBox(height: 5),
            const Text(
              'Please signin or signup to continue to use our app!',
              textAlign: TextAlign.left,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 10),
            const Padding(
              //padding: const EdgeInsets.only(left:15.0,right: 15.0,top:0,bottom: 0),
              padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Username',
                    hintText: 'Enter Email ID'),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 0),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                obscureText: true,
                decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Password',
                    hintText: 'Enter Password'),
              ),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: (){
                // ignore: todo
                //TODO FORGOT PASSWORD SCREEN GOES HERE
              },
              child: const Align(
                alignment: Alignment.centerRight, 
                child: Text("Forgot Password?", style: TextStyle(color: Colors.green, fontSize: 15)),
              ),
            ),
            const SizedBox(height: 10),
            Container(
              height: 40,
              width: 380,
              decoration: BoxDecoration(
                  color: Colors.green, borderRadius: BorderRadius.circular(5)),
              // ignore: prefer_const_constructors
              child: TextButton (
                onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => const SecondRoute()));
                },
                child: const Text(
                  'Login',
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            RichText(
              // ignore: prefer_const_constructors
              text: TextSpan(
                text: "Dont't have an account? ",
                style: const TextStyle(color: Colors.black, fontSize: 15),
                children: const <TextSpan>[
                  TextSpan(text: 'Signup', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 15)),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            RichText(
              // ignore: prefer_const_constructors
              text: TextSpan(
                text: " __________________ ",
                style: const TextStyle(color: Color.fromARGB(221, 189, 189, 189), fontSize: 15),
                children: const <TextSpan>[
                  TextSpan(text: 'or login with', style: TextStyle(color: Colors.black, fontSize: 15, height: 5)),
                  TextSpan(text: ' __________________', style: TextStyle(color: Color.fromARGB(221, 189, 189, 189), fontSize: 15)),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            SignInButton(
              Buttons.Google,
              onPressed: () {},
            ),
            const SizedBox(
              height: 10,
            ),
            SignInButton(
              Buttons.Facebook,
              onPressed: () {},
            )
          ],
        ),
      ),
    );
  }
}

class NewWidget extends StatelessWidget {
  const NewWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return RichText(
              // ignore: prefer_const_constructors
              text: TextSpan(
                text: "Dont't have an account? ",
                style: const TextStyle(color: Colors.black, fontSize: 15),
                children: const <TextSpan>[
                  TextSpan(text: 'Signup', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 15)),
                ],
              ),
            );
  }
}