import 'package:flutter/material.dart';
//import 'HomePage.dart';
import '../../ui/shared/footer.dart';
import '../../ui/pages/category.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      // ignore: unnecessary_new
      theme: new ThemeData(scaffoldBackgroundColor: const Color.fromARGB(255, 237, 237, 237)),
      debugShowCheckedModeBanner: false,
      home: const ThirdRoute(),
    );
  }
}

class ThirdRoute extends StatelessWidget {
  const ThirdRoute({super.key});
  
  get colorSearchBg => null;
  
  get onTap => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(249, 244, 246, 255),
      body: Center(
        // ignore: sort_child_properties_last
        child: Column(
          children: <Widget>[
            const SizedBox(height: 50),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // Column(
                //   children: const <Widget> [
                    // Align(
                    //   alignment: Alignment.centerLeft,
                    //   child: Icon(Icons.arrow_back, size: 30),
                    // )
                //     ],
                // ),
                TextButton (
                  onPressed: () {
                    Navigator.push(
                        context, MaterialPageRoute(builder: (_) => const SecondRoute()));
                  },
                  child: const Icon(Icons.arrow_back, size: 30, color: Color.fromARGB(255, 75, 75, 75)),
                ),
                Column(
                  children: <Widget> [
                    Image.asset('asset/images/logo_default.png', height: 80, width: 80)
                  ],
                ),
                Column(
                  children: <Widget> [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: const [
                            Align(
                              alignment: Alignment.centerRight,
                              child: Icon(Icons.location_on, size: 20),
                            )
                          ],
                        ),
                        Column(
                          children: const [
                            SizedBox(width: 5),
                          ],
                        ),
                        Column(
                          children: const [
                          Text(' Dhaka, Banassre', style: TextStyle(color: Color.fromARGB(255, 75, 75, 75), fontWeight: FontWeight.bold, fontSize: 16)),
                          ],
                        ),
                        Column(
                          children: const [
                            SizedBox(width: 5),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
                Column(
                  children: <Widget> [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: const [
                            Align(
                              alignment: Alignment.centerRight,
                              child: Icon(Icons.shopping_cart, size: 30),
                            )
                          ],
                        ),
                        Column(
                          children: const [
                            SizedBox(width: 10),
                          ],
                        ),
                        Column(
                          children: const [
                            Align(
                              alignment: Alignment.centerRight,
                              child: Icon(Icons.notifications, size: 30),
                            )
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            Column(
              children: const [
                Padding(
                  padding: EdgeInsets.only(
                  left: 20.0, right: 20.0, top: 15, bottom: 0),
                  child: TextField(
                    obscureText: true,
                    decoration: InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        border: InputBorder.none,
                        filled: true, //<-- SEE HERE
                        fillColor: Colors.white,
                        hintText: 'Enter Search Items',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  padding: const EdgeInsets.all(5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const SizedBox(width: 20),
                      Column(
                        children: const [
                          Icon(Icons.dashboard_customize, size: 30),
                        ],
                      ),
                      const SizedBox(width: 10),
                      Column(
                        children: const [
                          Text('Categories', style: TextStyle(color: Color.fromARGB(255, 75, 75, 75), fontWeight: FontWeight.bold, fontSize: 21)),
                        ],
                      ),
                      const SizedBox(width: 235),
                    ]
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child:  CustomScrollView(
              primary: false,
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              // resizeToAvoidBottomInset : false,
              slivers: <Widget>[
                SliverPadding(
                  padding: const EdgeInsets.all(10),
                  sliver: SliverGrid.count(
                    crossAxisSpacing: 0,
                    mainAxisSpacing: 0,
                    crossAxisCount: 3,
                    children: <Widget>[
                      Container(
                        padding: const EdgeInsets.all(2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset('asset/images/fruits-1.jpg', width: 100, height: 100, fit: BoxFit.fill),
                                ),
                                const SizedBox(height: 5),
                                const Text("Fruits", style: TextStyle(color: Colors.green, fontSize: 16, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ]
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset('asset/images/vegetables-1.jpg', width: 100, height: 100, fit: BoxFit.fill),
                                ),
                                const SizedBox(height: 5),
                                const Text("Vegitables", style: TextStyle(color: Colors.green, fontSize: 16, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ]
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset('asset/images/gourd-1.jpg', width: 100, height: 100, fit: BoxFit.fill),
                                ),
                                const SizedBox(height: 5),
                                const Text("Gourd", style: TextStyle(color: Colors.green, fontSize: 16, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ]
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset('asset/images/cereal-1.jpg', width: 100, height: 100, fit: BoxFit.fill),
                                ),
                                const SizedBox(height: 5),
                                const Text("Cereal", style: TextStyle(color: Colors.green, fontSize: 16, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ]
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset('asset/images/pulses-1.jpg', width: 100, height: 100, fit: BoxFit.fill),
                                ),
                                const SizedBox(height: 5),
                                const Text("Pulses", style: TextStyle(color: Colors.green, fontSize: 16, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ]
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset('asset/images/fruits-1.jpg', width: 100, height: 100, fit: BoxFit.fill),
                                ),
                                const SizedBox(height: 5),
                                const Text("Fruits", style: TextStyle(color: Colors.green, fontSize: 16, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ]
                        ),
                      ),
                      Container(
                        width: 100,
                        height: 100,
                        margin: const EdgeInsets.all(10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset('asset/images/vegetables-1.jpg', width: 100, height: 85, fit: BoxFit.fill),
                                ),
                                const SizedBox(height: 5),
                                const Text("Vegetables", style: TextStyle(color: Colors.green, fontSize: 16, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ]
                        )
                      ),
                    ],
                  ),
                ),
              ],
            )
          ), 
          ]
        )
      ),
      bottomNavigationBar: Container(
        height: 60.0,
        padding: const EdgeInsets.all(5),
        decoration: const BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(17.0),
            topLeft: Radius.circular(17.0),
          ),
          // ignore: unnecessary_const
          boxShadow: [  //BoxShadow
            BoxShadow(
              color: Color.fromARGB(255, 156, 156, 156),
              offset: Offset(10.0, 15.0),
              blurRadius: 10.0,
              spreadRadius: 10.0,
            ),
            BoxShadow(
              color: Color.fromARGB(255, 158, 158, 158),
              offset: Offset(10.0, 15.0),
              blurRadius: 10.0,
              spreadRadius: 10.0,
            ), //BoxShadow
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: const <Widget> [
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.add_shopping_cart, color: Colors.black, size: 30),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.shopping_bag, color: Colors.black, size: 30),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.home, color: Colors.black, size: 30),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.favorite, color: Colors.black, size: 30),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.restaurant, color: Colors.black, size: 30),
            ),
          ],
        ),
      )
    );
  }
}
