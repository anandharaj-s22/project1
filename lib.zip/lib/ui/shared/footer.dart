import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      // ignore: unnecessary_new
      theme: new ThemeData(scaffoldBackgroundColor: const Color.fromARGB(255, 237, 237, 237)),
      debugShowCheckedModeBanner: false,
      home: const FooterRoute(),
    );
  }
}

class FooterRoute extends StatelessWidget {
  const FooterRoute({super.key});
  
  get centerKey => null;
  
  get children => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        height: 60.0,
        padding: const EdgeInsets.all(5),
        decoration: const BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(17.0),
            topLeft: Radius.circular(17.0),
          ),
          // ignore: unnecessary_const
          boxShadow: [//BoxShadow//BoxShadow
            BoxShadow(
              color: Color.fromARGB(255, 156, 156, 156),
              offset: Offset(10.0, 15.0),
              blurRadius: 10.0,
              spreadRadius: 10.0,
            ),
            BoxShadow(
              color: Color.fromARGB(255, 158, 158, 158),
              offset: Offset(10.0, 15.0),
              blurRadius: 10.0,
              spreadRadius: 10.0,
            ), //BoxShadow
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: const <Widget> [
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.add_shopping_cart, color: Colors.black, size: 30),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.shopping_bag, color: Colors.black, size: 30),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.home, color: Colors.black, size: 30),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.favorite, color: Colors.black, size: 30),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.restaurant, color: Colors.black, size: 30),
            ),
          ],
        ),
      )
    );
  }
}